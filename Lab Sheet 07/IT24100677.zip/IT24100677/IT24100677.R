setwd("C:\\Users\\HP\\OneDrive\\Desktop\\IT24100677")
getwd()
#Q1
p <- punif(25, min = 0, max = 40) - punif(10, min = 0, max = 40)
print(p)

#Q2
pexp(2, rate = 1/3,lower.tail = TRUE)

#Q3
#i
1 - pnorm(130, mean = 100, sd = 15,lower.tail = TRUE)

#ii
qnorm(0.95, mean = 100, sd = 15)


